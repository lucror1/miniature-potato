# import necessary modules
import numpy as np
import matplotlib.pyplot as plt

# Import custom module
import fields
import visualize 

# Radius of the earth
r_earth = 6378.1e3 # m

# properties of our rocket
m_fuel_in = 395700.0 * 3 #kg
m_fuselage = 25600.0 * 3 #0.0255 - m_fuel_in #kg
m_payload = 1000.0 #kg

# properties of thrust
thrustTime = 500 #162.0 #s #the time the rocket is getting thrust force directly
tTime = 500 #397.0

# Change in mass per dt
# BUG: recalculate dm for second stage/include fuel for second stage
dm = m_fuel_in / (thrustTime + tTime + 200) #kg/s # dm/dt the fuel usage rate

# Thrust for each stage
stage_one_thrust = 7.607e6 * 3#7607000 * 3.0 # N
stage_two_thrust = 9.81e5 #981000.0 # N

thrust = np.array([stage_one_thrust,0.0]) #N #The thrust of the rocket
thrust2 = np.array([stage_two_thrust, 0.0])

# Total mass of the rocket
m = m_fuselage + m_fuel_in + m_payload # calc. the total initial mass

# define our simulation
t = 0.0
dt = 1 #0.1 # s, our time step

# initialize variables
pos = np.array([r_earth,0.0])

# https://www.scientificamerican.com/article/how-fast-is-the-earth-mov/
vel = np.array([460.0,0.0])
accel = np.array([0.0,0.0])
# max sim length
t_f = 10000.0 #40000.0 #s

# other constants
g = 9.8 #m/s/s

# initialize lists for plotting
x_list = [pos[0]]
y_list = [pos[1]]

# drag variables
drag = 0.0 # kg*m/s/s # initialize variable
radius = 0.945 * 0.0254 / 2 # m 
area = np.pi * radius ** 2.0 # cross sectional area of cone is pir^2
dcoe = 0.3 # drag coefficient of cones
adensity = 1.225 # kg/m^3
theta = 0

# main function loop
while t < t_f: # run for allotted simulation time at max
    # force calc for when thrust is running
    gForce = fields.gravityField(pos)
    dragForce = fields.dragField(pos, vel, A=area, r=r_earth, cd=dcoe)

    if t > thrustTime / 2:
        theta = np.pi/8
    if t > thrustTime:
        theta = np.pi/2

    if t < thrustTime:
        thrust[0] = stage_one_thrust * np.cos(theta)
        thrust[1] = stage_one_thrust * np.sin(theta)
        F = thrust + np.array([m,m]) * (gForce) + dragForce # force calc.
        m -= dm * dt
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    # force calc for no thrust
    elif thrustTime < t < (tTime + thrustTime):
        thrust2[0] = stage_two_thrust * np.cos(theta)
        thrust2[1] = stage_two_thrust * np.sin(theta)
        F = thrust2 + np.array([m,m]) * (gForce) + dragForce
        m -= dm * dt
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    else:
        # Calculate the force
        F = np.array([m,m]) * gForce + dragForce
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    
    # append to lists
    x_list.append(pos[0])
    y_list.append(pos[1])
        
plt.plot(x_list, y_list, 'r')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Rocket')

earth_x, earth_y = visualize.genEarthLists()
plt.plot(earth_x, earth_y)

target_x, target_y = visualize.genEarthLists(6378.1e3 + 2000e3)
plt.plot(target_x, target_y)

#plt.gca().set_aspect("equal")
plt.show()