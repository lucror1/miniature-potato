# import necessary modules
import numpy as np
import matplotlib.pyplot as plt

# Import custom module
import fields
import visualize 

# Radius of the earth
r_earth = 6378.1e3 # m

# properties of our rocket
m_fuel_in = 395700.0 * 3 #kg
m_fuselage = 25600.0 * 3 #0.0255 - m_fuel_in #kg
m_payload = 1000.0 #kg

# properties of thrust
thrustTime = 162.0 #s #the time the rocket is getting thrust force directly
tTime = 397.0

# Change in mass per dt
dm = m_fuel_in / (thrustTime + tTime + 200) #kg/s # dm/dt the fuel usage rate

# Thrust for each stage
thrust = np.array([7607000 * 3.0,0.0]) #N #The thrust of the rocket
thrust2 = np.array([981000.0, 0.0])

# Total mass of the rocket
m = m_fuselage + m_fuel_in + m_payload # calc. the total initial mass

# define our simulation
t = 0.0
dt = 0.1 # s, our time step

# initialize variables
pos = np.array([r_earth,0.0])

# https://www.scientificamerican.com/article/how-fast-is-the-earth-mov/
vel = np.array([460.0,0.0])
accel = np.array([0.0,0.0])
# max sim length
t_f = 40000.0 #s

# other constants
g = 9.8 #m/s/s

# initialize lists for plotting
x_list = [pos[0]]
y_list = [pos[1]]
t_list = [t]
mass_list = [m]
vx_list = [vel[0]]
vy_list = [vel[1]]
ax_list = [accel[0]]
ay_list = [accel[1]]

# drag variables
drag = 0.0 # kg*m/s/s # initialize variable
radius = 0.945 * 0.0254 / 2 # m 
area = np.pi * radius ** 2.0 # cross sectional area of cone is pir^2
dcoe = 0.3 # drag coefficient of cones
adensity = 1.225 # kg/m^3
theta = 0

# main function loop
gList = []
gList2 = []
while t < (tTime + thrustTime): # run for allotted simulation time at max
    #assert m >= m_payload + m_fuselage
    
    # force calc for when thrust is running
    gForce = fields.gravityField(pos)
    gList.append(gForce[0])
    gList2.append(gForce[1])
    
    dragForce = fields.dragField(pos, vel, A=area, r=r_earth, cd=dcoe)

    if t < thrustTime: #m > (m_fuselage + m_payload):
        thrust[0] = 7607000.0 * 3 * np.cos(theta)
        thrust[1] = 7607000.0 * 3 * np.sin(theta)
        theta += (np.pi/8 * 16200)
        #drag = (dcoe)*(area)*adensity * np.sign(v) * 0.5 * v * v
        F = thrust + np.array([m,m]) * (gForce) + dragForce # force calc.
        m -= dm * dt
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    # force calc for no thrust
    elif thrustTime < t < (tTime + thrustTime):
        thrust2[0] = 981000 * np.cos(theta)
        thrust2[1] = 981000 * np.sin(theta)
        F = thrust2 + np.array([m,m]) * (gForce) + dragForce
        theta += (10/16200)
        m -= dm * dt
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    else:
        #drag = (dcoe)*(area)*adensity*np.sign(v)*v*v*0.5
        F = np.array([m,m]) * (gForce) + dragForce
        accel = F / m
        # acceleration based function
        vel += accel * dt
        pos += vel * dt
        t += dt
    # append to lists

    x_list.append(pos[0])
    vx_list.append(vel[0])
    ax_list.append(vel[0])
    y_list.append(pos[1])
    vy_list.append(vel[1])
    ay_list.append(accel[1])
    mass_list.append(m)
    t_list.append(t)
        
plt.plot(x_list, y_list, 'r.')

plt.xlabel('X')
plt.ylabel('Y')
plt.title('Rocket')

X, Y, gx, gy = visualize.genGravityLists()
plt.quiver(X, Y, gx, gy)

earth_x, earth_y = visualize.genEarthLists()
plt.plot(earth_x, earth_y)

plt.gca().set_aspect("equal")
plt.show()